package Patient;

import java.util.Scanner;

public class PatientDriverApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Input Patient information
            System.out.println("Enter Patient First Name: ");
            String firstName = scanner.nextLine();
            System.out.println("Enter Patient Middle Name: ");
            String middleName = scanner.nextLine();
            System.out.println("Enter Patient Last Name: ");
            String lastName = scanner.nextLine();
            System.out.println("Enter Patient Street Address: ");
            String streetAddress = scanner.nextLine();
            System.out.println("Enter Patient City: ");
            String city = scanner.nextLine();
            System.out.println("Enter Patient State: ");
            String state = scanner.nextLine();
            System.out.println("Enter Patient ZIP Code: ");
            String zipCode = scanner.nextLine();
            System.out.println("Enter Patient Phone Number: ");
            String phoneNumber = scanner.nextLine();
            System.out.println("Enter Emergency Contact Name: ");
            String emergencyContactName = scanner.nextLine();
            System.out.println("Enter Emergency Contact Phone: ");
            String emergencyContactPhone = scanner.nextLine();

            // Create Patient instance
            Patient patient = new Patient(firstName, middleName, lastName, streetAddress, city, state, zipCode, phoneNumber, emergencyContactName, emergencyContactPhone);

            // Create Procedure instances
            Procedure procedure1 = new Procedure();
            procedure1.setProcedureName("Procedure 1");
            procedure1.setProcedureDate("01/01/2023");
            procedure1.setPractitionerName("Dr. Smith");
            procedure1.setProcedureCharge(100.00);

            Procedure procedure2 = new Procedure("Procedure 2", "02/01/2023");
            procedure2.setPractitionerName("Dr. Jones");
            procedure2.setProcedureCharge(200.00);

            Procedure procedure3 = new Procedure("Procedure 3", "03/01/2023", "Dr. Brown", 300.00);

            // Display Patient and Procedure information
            displayPatient(patient);
            displayProcedure(procedure1);
            displayProcedure(procedure2);
            displayProcedure(procedure3);

            // Calculate and display total charges
            double totalCharges = calculateTotalCharges(procedure1, procedure2, procedure3);
            System.out.printf("Total Charges: $%,.2f%n", totalCharges);
            
            // Display the developed message
            System.out.println("The program was developed by a Student: <Your Name> <07/27/24>");
        } finally {
            // Ensure Scanner is closed or not mvzz			qqqq
            if (scanner != null) {
                scanner.close();
            }
        }
    }

    public static void displayPatient(Patient patient) {
        System.out.println(patient);
    }

    public static void displayProcedure(Procedure procedure) {
        System.out.println(procedure);
    }

    public static double calculateTotalCharges(Procedure proc1, Procedure proc2, Procedure proc3) {
        return proc1.getProcedureCharge() + proc2.getProcedureCharge() + proc3.getProcedureCharge();
    }
}
